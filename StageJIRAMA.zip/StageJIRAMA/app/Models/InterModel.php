<?php

namespace App\Models;

use CodeIgniter\Model;

class InterModel extends Model
{
   protected $table = "intervenant";

   protected $primaryKey ="num_matri";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["num_matri","nom_int","prenom_int","tel_int","categorie_int","email_int","adresse_int","id_fonc","id_sect"];


   public function get_intervenant()
	{
		return $this->db
					->table($this->table)
					->join('fonction','fonction.id_fonc = intervenant.id_fonc')
					->join('sectionanalytique','sectionanalytique.id_sect= intervenant.id_sect')
					->get()
					->getResultObject();
	}
	public function select_nom(){
		
		return $this->db
					->table('intervenant')
					->select('*')
					->join('fonction','fonction.id_fonc = intervenant.id_fonc')
					->join('sectionanalytique','sectionanalytique.id_sect= intervenant.id_sect')
					->where('categorie_int','intervenant')
					->get()
					->getRowObject();
	}
	
}