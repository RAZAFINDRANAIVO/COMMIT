<?php

namespace App\Models;

use CodeIgniter\Model;

class LoginModel extends Model
{
   protected $table = "login";

   protected $primaryKey ="id_log";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["nom_log","prenom_log","email_log","password"];


}