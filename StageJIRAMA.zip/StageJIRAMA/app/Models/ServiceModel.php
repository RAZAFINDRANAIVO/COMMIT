<?php

namespace App\Models;

use CodeIgniter\Model;

class ServiceModel extends Model
{
   protected $table = "service";

   protected $primaryKey ="id_serv";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["code_serv","id_depar"];



   public function get_service()
	{
		return $this->db
					->table($this->table)
					->join('departement','departement.id_depar = service.id_depar')
					->get()
					->getResultObject();
	}
}