<?php

namespace App\Models;

use CodeIgniter\Model;

class LocalModel extends Model
{
   protected $table = "localisation";

   protected $primaryKey ="id_local";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["nom_local","id_serv"];


   public function get_local()
	{
		return $this->db
					->table($this->table)
					->join('service','service.id_serv = localisation.id_serv')
					->get()
					->getResultObject();
	}
}