<?php

namespace App\Models;

use CodeIgniter\Model;

class DepartModel extends Model
{
   protected $table = "departement";

   protected $primaryKey ="id_depar";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["code_depar","id_dir"];



   public function get_departement()
	{
		return $this->db
					->table($this->table)
					->join('direction','direction.id_dir = departement.id_dir')
					->get()
					->getResultObject();
	}
}