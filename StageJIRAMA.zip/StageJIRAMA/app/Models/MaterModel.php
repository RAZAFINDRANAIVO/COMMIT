<?php

namespace App\Models;

use CodeIgniter\Model;

class MaterModel extends Model
{
   protected $table = "materiel";

   protected $primaryKey ="id_mate";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["num_serie","code_mate","marque","model","caracteristique"];


}