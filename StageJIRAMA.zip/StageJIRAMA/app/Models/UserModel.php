<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
   protected $table = "utilisateur";

   protected $primaryKey ="num_mat";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["num_mat","nom","prenom","categorie","tel","email","adresse","id_fonc","id_sect"];


   public function get_utilisateur()
	{
		return $this->db
					->table($this->table)
					->join('fonction','fonction.id_fonc = utilisateur.id_fonc')
					->join('sectionanalytique','sectionanalytique.id_sect= utilisateur.id_sect')
					->get()
					->getResultObject();
	}
	
}