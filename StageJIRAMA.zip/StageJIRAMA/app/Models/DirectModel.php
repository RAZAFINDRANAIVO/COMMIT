<?php

namespace App\Models;

use CodeIgniter\Model;

class DirectModel extends Model
{
   protected $table = "direction";

   protected $primaryKey ="id_dir";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["code_dir","site"];


}