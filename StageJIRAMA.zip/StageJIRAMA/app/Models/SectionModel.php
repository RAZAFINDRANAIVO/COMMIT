<?php

namespace App\Models;

use CodeIgniter\Model;

class SectionModel extends Model
{
   protected $table = "sectionanalytique";

   protected $primaryKey ="id_sect";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["code_sect","type","id_serv"];


   public function get_section()
	{
		return $this->db
					->table($this->table)
					->join('service','service.id_serv = sectionanalytique.id_serv')
					->get()
					->getResultObject();
	}
}