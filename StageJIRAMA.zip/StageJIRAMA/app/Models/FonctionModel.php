<?php

namespace App\Models;

use CodeIgniter\Model;

class FonctionModel extends Model
{
   protected $table = "fonction";

   protected $primaryKey ="id_fonc";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["nom_fonction","code_fonction"];


}