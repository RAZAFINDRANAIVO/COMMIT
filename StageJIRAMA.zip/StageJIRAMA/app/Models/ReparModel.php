<?php

namespace App\Models;

use CodeIgniter\Model;

class ReparModel extends Model
{
   protected $table = "reparation";

   protected $primaryKey ="id_repar";

   protected $useAutoIncrement = "true";

   protected $allowedFields =["date_recep","date_recuper","etat","observation","id_mate","domaine","num_mat","situation","libelle","num_inter"];

   public function get_reparation()
	{
		return $this->db
					->table($this->table)
					->join('utilisateur','utilisateur.num_mat = reparation.num_mat')
                    ->join('materiel','materiel.id_mate = reparation.id_mate')
					->get()
					->getResultObject();
	}

    public function select_data()
	{
		return $this->db
					->table('reparation')
					->select('*')
					->join('utilisateur','utilisateur.num_mat = reparation.num_mat','inner')
                    ->join('materiel','materiel.id_mate = reparation.id_mate','inner')
					->join('sectionanalytique','utilisateur.id_sect = sectionanalytique.id_sect','inner')
					->join('service','sectionanalytique.id_serv = service.id_serv','inner')
					->join('localisation','service.id_serv = localisation.id_serv','inner')	
					->join('departement','departement.id_depar = service.id_depar','inner')
					->join('direction','direction.id_dir = departement.id_dir')
					->join('fonction','fonction.id_fonc = utilisateur.id_fonc')
					->get()
					->getResultObject();
	}
	public function select_where(int $id_repar)
	{
		return $this->db
					->table('reparation')
					->select('*')
					->join('utilisateur','utilisateur.num_mat = reparation.num_mat','inner')
                    ->join('materiel','materiel.id_mate = reparation.id_mate','inner')
					->join('sectionanalytique','utilisateur.id_sect = sectionanalytique.id_sect','inner')
					->join('service','sectionanalytique.id_serv = service.id_serv','inner')
					->join('localisation','service.id_serv = localisation.id_serv','inner')	
					->join('departement','departement.id_depar = service.id_depar','inner')
					->join('direction','direction.id_dir = departement.id_dir')
					->join('fonction','fonction.id_fonc = utilisateur.id_fonc')
					->where('reparation.id_repar',$id_repar)
					->get()
					->getResultObject();
	}
	


}