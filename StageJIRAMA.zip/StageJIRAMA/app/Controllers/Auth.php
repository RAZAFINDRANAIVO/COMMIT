<?php

namespace App\Controllers;
use App\Models\LoginModel;
use App\Libraries\Hash;

class Auth extends BaseController
{
	public function __construct()
	{
		helper(['url','form']);
	}
	public function index()
	{
		return view('Auth/login');
	}
	public function register(){
		return view('Auth/register');
	}
	public function check(){
		$validation = $this->validate([
            "email" => [
                "rules" => "required|valid_email|is_not_unique[login.email_log]",
                "errors" => [
                    "required" => "ce champ ne doit pa être vide",
                    "valid_email" => "Entrer un email validé",
                    "is_not_unique" => "Ce compte n'existe pas sur notre service"
                ]
            ],
            "password" => [
                "rules" => "required|min_length[6]|max_length[12]",
                "errors" => [
                    "required" => "ce champ ne doit pas être vide",
                    "min_length" => "Mot de passe au moins 6 caractères",
                    "max_length" => "Mot de passe moins de 12 caractères"
                ]
            ]
        ]);
		if (!$validation) {
            return view("Auth/login",["validation" => $this->validator]);
        }else{

            $email = $this->request->getPost('email');
			$password = $this->request->getPost('password');
			$loginModel = new LoginModel();
			$user = $loginModel->where('email_log',$email)->first();
			$check_password = Hash::check($password,$user['password']);
			
			if(!$check_password){
				session()->setFlashdata('fail','Email ou Mot de passe incorrect');
                return redirect()->to('/Auth')->withInput();
			}else{
				$user_id =$user['id_log'];
				session()->set('loggedUser',$user_id);
				return view('Home');
			}
        }
	}
	public function save(){
		$validation = $this->validate([
			'firstname'  =>[
				'rules'=>'required',
				'errors'=>'ce champs ne doit pas être vide'
				],
			'lastname'  =>[
				'rules'=>'required',
				'errors'=>'ce champs ne doit pas être vide'
				],
            "email" => [
                "rules" => "required|valid_email|is_unique[login.email_log]",
                "errors" => [
                    "required" => "ce champs ne doit pas être vide",
                    "valid_email" => "Entrer un email validé ",
                    "is_unique" => "Email déja pris"
                ]
            ],
            "password" => [
                "rules" => "required|min_length[6]|max_length[12]",
                "errors" => [
                    "required" => "ce champs ne doit pas être vide",
                    "min_length" => "Mot de passe au moins 6 caractères",
                    "max_length" => "Mot de passe doit être moins de 12 caractère"
                ]
			],
			"confirmpassword" => [
				"rules" => "required|min_length[6]|max_length[12]|matches[password]",
				"errors" => [
					"required" => "ce champs ne doit pas être vide",
					"min_length" => "Mot de passe au moins 6 caractères",
					"max_length" => "Mot de passe doit être moins de 12 caractère",
					"matches" => "Vous devez confirmer votre mot de passe "
			]
			]
        ]);
		if(!$validation){
            return view('Auth/register',['validation' => $this->validator]);
		}
		else{
			
			$firstname = $this->request->getPost('firstname');
			$lastname = $this->request->getPost('lastname');
			$email = $this->request->getPost('email');
			$password = $this->request->getPost('password');

			$values = [
				'nom_log'=>$firstname,
				'prenom_log'=>$lastname,
				'email_log'=>$email,
				'password'=>Hash::make($password),
            ];

			$loginModel = new LoginModel();
			$query = $loginModel->insert($values);

			if(!$query){

				return redirect()->back()->with('fail','Something went wrong');

			}else{
				return redirect()->to('register')->with('success','You are now registred successfully');
			}
		}

	}

}
