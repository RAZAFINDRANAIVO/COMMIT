<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\SectionModel;
use App\Models\ServiceModel;

class Section extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $section = new SectionModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'section' =>$section->get_section(),
            ] ;
        return view('Section/index',$data);
    }
    public function delete($id_sect){
        $section = new SectionModel();
        $section->delete($id_sect);
        return $this->response->redirect(site_url('Section/index'));
    }
    public function edit($id_sect){
        $section = new SectionModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'section' =>$section->find($id_sect),
            ] ;
        return view('Section/edit',$data);
    }
    public function update(){
        
        $section = new SectionModel();
        $id_sect =$this->request->getVar('id_sect');
        $data =[
            'code_sect'=>$this->request->getPost('code_sec'),
            'type'=>$this->request->getPost('typ_sec'),
			'id_serv'=>$this->request->getPost('code_ser'),
        ];
        $section->update($id_sect,$data);
        return $this->response->redirect(site_url('Section/index'));
    }
    public function add(){
        $section = new SectionModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'section' =>$section->get_section(),
            ] ;
        return view('Section/add',$data);
    }
    public function save(){
        $section = new SectionModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'departement' => $section->get_section(),
            ] ;
			
			
			$values = [
				'code_sect'=>$this->request->getPost('code_sec'),
                'type'=>$this->request->getPost('typ_sec'),
				'id_serv'=>$this->request->getPost('code_ser'),
			
            ];

		if(!($section->insert($values))){

			return redirect()->back()->with('fail','Something went wrong');

		}else{
			return redirect()->to('index')->with('success','You are now registred successfully');
		}

		return view('Section/index',$data);
	
    }
   
}