<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DirectModel;

class Direction extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $directModel = new DirectModel();
        $data['directions'] = $directModel->findAll();
        return view('Direction/index',$data);
    }
    public function delete($id_dir){
        $directModel = new DirectModel();
        $directModel->delete($id_dir);
        return $this->response->redirect(site_url('Direction/index'));
    }
    public function edit($id_dir){
        $directModel = new DirectModel();
        $data['direction'] = $directModel->find($id_dir);
        return view('Direction/edit',$data);
    }
    public function update(){
        $directModel = new DirectModel();
        $id_dir = $this->request->getVar('id_dir');
        $data=[
            'code_dir' => $this->request->getVar('code'),
			'site' => $this->request->getVar('site')
        ];
        $directModel ->update($id_dir,$data);
        return $this->response->redirect(site_url('Direction/index'));
    }
    public function add(){
        return view('Direction/add');
    }
    public function save(){
        $validation = $this->validate([
			'code'  =>[
				'rules'=>'required',
				'errors'=>'ce champ ne doit pas être vide'
				],
			'site'  =>[
				'rules'=>'required',
				'errors'=>'ce champ ne doit pas être vide'
				]
          
        ]);
        if(!$validation){
            return view('Direction/add',['validation' => $this->validator]);
		}
		else{
			
			$code = $this->request->getPost('code');
			$site = $this->request->getPost('site');
			

			$values = [
				'code_dir'=>$code,
				'site'=>$site,
				
				
            ];

			$directModel = new DirectModel();
			$query = $directModel->insert($values);
            
            

			if(!$query){

				return redirect()->back()->with('fail','Something went wrong');

			}else{
				return $this->response->redirect(site_url('Direction/index'));
			}
		}

    }

}