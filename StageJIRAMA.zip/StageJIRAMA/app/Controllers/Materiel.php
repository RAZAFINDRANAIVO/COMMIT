<?php
namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\MaterModel;

class Materiel extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $materielModel = new MaterModel();
        $data['materiels'] =$materielModel->findAll();
        return view('Materiel/index',$data);
    }
    public function delete($id_mate){
        $materielModel = new MaterModel();
        $materielModel->delete($id_mate);
        return $this->response->redirect(site_url('Materiel/index'));
    }
    public function edit($id_mate){
        $materielModel = new MaterModel();
        $data['materiel'] =$materielModel->find($id_mate);
        return view('Materiel/edit',$data);
    }
    public function update(){
        $materielModel = new MaterModel();
        $materielModel->update($_POST['id_mate'],$_POST);
        return $this->response->redirect(site_url('Materiel/index'));
    }
    public function add(){
        return view('Materiel/add');
    }
    public function save(){
        $validation = $this->validate([
			'serie'  =>[
				'rules'=>'required',
				'errors'=>'ce champ ne doit pas être vide'
				],
			'code'  =>[
				'rules'=>'required',
				'errors'=>'ce champ ne doit pas être vide'
				],
            "marque" => [
                "rules" => "required",
                'errors'=>'ce champ ne doit pas être vide'
            ],
            "model" => [
                "rules" => "required",
                'errors'=>'ce champ ne doit pas être vide'
			],
			"caract" => [
				"rules" => "required",
				'errors'=>'ce champ ne doit pas être vide'
			]
        ]);
        if(!$validation){
            return view('Materiel/add',['validation' => $this->validator]);
		}
		else{
			
			$serie = $this->request->getPost('serie');
			$code = $this->request->getPost('code');
			$marque= $this->request->getPost('marque');
			$model = $this->request->getPost('model');
            $caract = $this->request->getPost('caract');

			$values = [
				'num_serie'=>$serie,
				'code_mate'=>$code,
				'marque'=>$marque,
                'model'=>$model,
                'caracteristique'=>$caract,
				
            ];

			$materielModel = new MaterModel();
			$query = $materielModel->insert($values);
            
            

			if(!$query){

				return redirect()->back()->with('fail','Something went wrong');

			}else{
				return $this->response->redirect(site_url('Materiel/index'));
			}
		}

    }
}
