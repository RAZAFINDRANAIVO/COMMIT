<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\FonctionModel;
use App\Models\SectionModel;

class User extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $fonctModel = new FonctionModel;
        $userModel = new UserModel();
        $section = new SectionModel();
        $data =[
            'fonction' => $fonctModel->findAll(),
            'user' =>$userModel ->get_utilisateur(),
            'section'=>$section ->findAll(),
            ] ;
        return view('User/index',$data);
    }
    public function delete($num_mat){
        $userModel = new UserModel();
        $userModel->delete($num_mat);
        return $this->response->redirect(site_url('User/index'));
    }
    public function edit($num_mat){
        $fonctModel = new FonctionModel;
        $userModel = new UserModel();
        $section = new SectionModel();
        $data =[
            'fonction' => $fonctModel->findAll(),
            'user' =>$userModel ->find($num_mat),
            'section'=>$section ->findAll(),
            ] ;
        return view('User/edit',$data);
    }
    public function update(){
        
        $userModel = new UserModel();
        $num_mat =$this->request->getVar('num_mat');
        $data =[
            'num_mat'=>$this->request->getPost('num'),
            'nom'=>$this->request->getPost('nom'),
            'prenom'=>$this->request->getPost('pre'),
            'categorie'=>$this->request->getPost('cate'),
            'tel'=>$this->request->getPost('phone'),
            'email'=>$this->request->getPost('email'),
            'adresse'=>$this->request->getPost('adr'),
            'id_fonc'=>$this->request->getPost('code'),
            'id_sect'=>$this->request->getPost('id_se'),
        ];
        $userModel->update($num_mat,$data);
        return $this->response->redirect(site_url('User/index'));
    }
    public function add(){
        $fonctModel = new FonctionModel;
        $userModel = new UserModel();
        $section = new SectionModel();
        $data =[
            'fonction' => $fonctModel->findAll(),
            'user' =>$userModel ->get_utilisateur(),
            'section'=>$section ->findAll(),
            ] ;
        return view('User/add',$data);
    }
    public function save(){
        $fonctModel = new FonctionModel;
        $userModel = new UserModel();
        $section = new SectionModel();
        $data =[
            'fonction' => $fonctModel->findAll(),
            'user' =>$userModel ->get_utilisateur(),
            'section'=>$section ->findAll(),
            ] ;
     	
			$values = [
				'num_mat'=>$this->request->getPost('num'),
                'nom'=>$this->request->getPost('nom'),
                'prenom'=>$this->request->getPost('pre'),
                'categorie'=>$this->request->getPost('cate'),
                'tel'=>$this->request->getPost('phone'),
                'email'=>$this->request->getPost('email'),
                'adresse'=>$this->request->getPost('adr'),
                'id_fonc'=>$this->request->getPost('code'),
                'id_sect'=>$this->request->getPost('id_se'),
			
            ];

		
			$userModel = new UserModel();
			$query =$userModel ->insert($values);
            
            

			if(!$query){

				return redirect()->back()->with('fail','Something went wrong');

			}else{
				return $this->response->redirect(site_url('User/index'));
			}

		return view('User/index',$data);
       
    }
   
}