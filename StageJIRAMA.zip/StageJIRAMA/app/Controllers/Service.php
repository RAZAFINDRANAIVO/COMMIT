<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DepartModel;
use App\Models\ServiceModel;

class Service extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $departModel = new DepartModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->get_service(),
            'departement' =>$departModel->findAll(),
            ] ;
        return view('Servic/index',$data);
    }
    public function delete($id_serv){
        $serviceModel = new ServiceModel();
        $serviceModel->delete($id_serv);
        return $this->response->redirect(site_url('Service/index'));
    }
    public function edit($id_serv){
        $departModel = new DepartModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->find($id_serv),
            'departement' =>$departModel->findAll(),
            ] ;
        return view('Servic/edit',$data);
    }
    public function update(){
        
        $serviceModel = new ServiceModel();
        $id_serv =$this->request->getVar('id_serv');
        $data =[
            'code_serv'=>$this->request->getVar('code_ser'),
			'id_depar'=>$this->request->getVar('code_dep'),
        ];
        $serviceModel->update($id_serv,$data);
        return $this->response->redirect(site_url('Service/index'));
    }
    public function add(){
        $departModel = new DepartModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->get_service(),
            'departement' =>$departModel->findAll(),
            ] ;
        return view('Servic/add',$data);
    }
    public function save(){
        $departModel = new DepartModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->get_service(),
            'departement' =>$departModel->findAll(),
            ] ;
			
			
			$values = [
				'code_serv'=>$this->request->getPost('code_ser'),
				'id_depar'=>$this->request->getPost('code_dep'),
			
            ];

		if(!($serviceModel->insert($values))){

			return redirect()->back()->with('fail','Something went wrong');

		}else{
			return redirect()->to('index')->with('success','You are now registred successfully');
		}

		return view('Servic/index',$data);
	
    }
   
}