<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LocalModel;
use App\Models\ServiceModel;

class Localisation extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $local = new LocalModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'locale' =>$local->get_local(),
            ] ;
        return view('Localisation/index',$data);
    }
    public function delete($id_local){
        $local = new LocalModel();
        $local->delete($id_local);
        return $this->response->redirect(site_url('Localisation/index'));
    }
    public function edit($id_local){
        $local = new LocalModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'locale' =>$local->find($id_local),
            ] ;
        return view('Localisation/edit',$data);
    }
    public function update(){
        
        $local = new LocalModel();
        $id_local =$this->request->getPost('id_depar');
        $data =[
            'nom_local'=>$this->request->getPost('code_lo'),
                
			'id_serv'=>$this->request->getPost('code_ser'),
        ];
        $local->update($id_local,$data);
        return $this->response->redirect(site_url('Localisation/index'));
    }
    public function add(){
        $local = new LocalModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'locale' =>$local->get_local(),
            ] ;
        return view('Localisation/add',$data);
    }
    public function save(){
        $local = new LocalModel();
        $serviceModel = new ServiceModel();
        $data =[
            'service' => $serviceModel->findAll(),
            'locale' => $local->get_local(),
            ] ;
			
			
			$values = [
				'nom_local'=>$this->request->getPost('code_lo'),
                
				'id_serv'=>$this->request->getPost('code_ser'),
			
            ];

		if(!($local->insert($values))){

			return redirect()->back()->with('fail','Something went wrong');

		}else{
			return redirect()->to('index')->with('success','You are now registred successfully');
		}

		return view('Localisation/index',$data);
	
    }
   
}