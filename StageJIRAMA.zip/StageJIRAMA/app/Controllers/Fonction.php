<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\FonctionModel;

class Fonction extends BaseController
{
    public function __construct()
    {
        helper(['url','form']);
    }
    public function index(){
        $fonctModel = new FonctionModel();
        $data['fonctions'] = $fonctModel ->findAll();
        return view('Fonction/index',$data);
    }
    public function delete($id_fonc){
        $fonctModel = new FonctionModel();
        $fonctModel ->delete($id_fonc);
        return $this->response->redirect(site_url('Fonction/index'));
    }
    public function edit($id_fonc){
        $fonctModel = new FonctionModel();
        $data['fonction'] =$fonctModel ->find($id_fonc);
        return view('Fonction/edit',$data);
    }
    public function update(){
        $fonctModel = new FonctionModel(); 
        $id_fonc = $this->request->getVar('id_fonc');
        $data = [
            'nom_fonction'=>$this->request->getVar('nom'),
			'code_fonction'=>$this->request->getVar('code'),
        ];
        $fonctModel->update($id_fonc,$data);

        return $this->response->redirect(site_url('Fonction/index'));
    }
    public function add(){
        return view('Fonction/add');
    }
    public function save(){
        $validation = $this->validate([
			'nom'  =>[
				'rules'=>'required',
				'errors'=>'ce champ ne doit pas être vide'
				],
            'nom'  =>[
               'rules'=>'required',
                'errors'=>'ce champ ne doit pas être vide'
                ],
			
        ]);
        if(!$validation){
            return view('Fonction/add',['validation' => $this->validator]);
		}
		else{
			
			$nom = $this->request->getPost('nom');
			$code = $this->request->getPost('code');
			

			$values = [
				'nom_fonction'=>$nom,
				'code_fonction'=>$code,
				
				
            ];

			$fonctModel = new FonctionModel();
			$query =  $fonctModel ->insert($values);
            
            

			if(!$query){

				return redirect()->back()->with('fail','Something went wrong');

			}else{
				return $this->response->redirect(site_url('Fonction/index'));
			}
		}

    }

}