<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DepartModel;
use App\Models\DirectModel;

class  Departement extends BaseController
{
    public function __construct()
	{
        helper(['url', 'form']);
	}
	
	public function index()
	{
		$departModel = new DepartModel();
        $directModel = new DirectModel();
        $data =[
            'direction' => $directModel->findAll(),
            'departement' =>$departModel->get_departement(),
            ] ;
		
		return view('Departement/index', $data);
	}
	public function add(){
		$departModel = new DepartModel();
        $directModel = new DirectModel();
        $data =[
            'direction' => $directModel->findAll(),
            'departement' =>$departModel->get_departement(),
            ] ;
		
		return view('Departement/add',$data);
	}
	public function save(){
		$departModel = new DepartModel();
        $directModel = new DirectModel();
        $data =[
            'direction' => $directModel->findAll(),
            'departement' =>$departModel->get_departement(),
            ] ;
			
			$code = $this->request->getPost('code');
			$cod = $this->request->getPost('Code_dir');

			$values = [
				'code_depar'=>$code,
				'id_dir'=>$cod,
			
            ];
			
			
		
		if(!($departModel->insert($values))){

			return redirect()->back()->with('fail','Something went wrong');

		}else{
			return redirect()->to('index')->with('success','You are now registred successfully');
		}

		return view('Departement/index',$data);
	}
	public function edit($id_depar){
		$departModel = new DepartModel();
        $directModel = new DirectModel();
        $data =[
            'direction' => $directModel->findAll(),
            'departement' =>$departModel->find($id_depar),
            ] ;
        return view('Departement/edit',$data);
	}
	public function update(){
		$departModel = new DepartModel();
        $id_depar = $this->request->getVar('id_depar');
		$data =[
			'code_depar'=> $this->request->getVar('code'),
			'id_dir'=>$this->request->getVar('Code_dir'),
		];
		$departModel->update($id_depar,$data);

		return $this->response->redirect(site_url('Departement/index')); 
	}
	public function delete($id_depar){
        $departModel = new DepartModel();
		$departModel->delete($id_depar);

		return $this->response->redirect(site_url('Departement/index'));
	}

   
}