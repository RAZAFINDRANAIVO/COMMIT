<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ReparModel;
use App\Models\UserModel;
use App\Models\MaterModel;
use  App\Models\InterModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


class  Reparation extends BaseController
{
    public function __construct()
	{
        helper(['url', 'form']);
	}
	
	public function index()
	{
		$reparat= new ReparModel();
		$user = new UserModel();
		$mater= new MaterModel();
		$inter= new InterModel();
	
			$data =[
				'user' => $user->findAll(),
				'materiel' => $mater->findAll(),
				'reparation' =>$reparat->get_reparation(),
				'inter'=>$inter->findAll(),
				'Inter'=>$inter->select_nom(),
				] ;
	
		
		return view('Reparation/index', $data);
	}
	public function add(){
		
		$reparat= new ReparModel();
		$user = new UserModel();
		$mater= new MaterModel();
		$inter= new InterModel();
        $data =[
            'user' => $user->findAll(),
			'materiel' => $mater->findAll(),
            'reparation' =>$reparat->get_reparation(),
			'inter'=>$inter->findAll(),
			'Inter'=>$inter->select_nom(),
            ] ;
		
		return view('Reparation/add',$data);
	}
	public function save(){
		
		$reparat= new ReparModel();
		$user = new UserModel();
		$mater= new MaterModel();
		$inter= new InterModel();
        $data =[
            'user' => $user->findAll(),
			'materiel' => $mater->findAll(),
            'reparation' =>$reparat->get_reparation(),
			'inter'=>$inter->findAll(),
			'Inter'=>$inter->select_nom(),
            ] ;

			$values = [
				'date_recep'=> $this->request->getPost('dat'),
				'date_recup'=> $this->request->getPost('date'),
				'etat'=> $this->request->getPost('eta'),
				'observation'=> $this->request->getPost('obs'),
				'id_mate'=> $this->request->getPost('id'),
				'domaine'=> $this->request->getPost('dom'),
				'num_mat'=> $this->request->getPost('num'),
				'situation'=> $this->request->getPost('si'),
				'libelle'=> $this->request->getPost('lib'),
				'num_matri'=> $this->request->getPost('nume'),
            ];
        if(!($reparat->insert($values))){

			return redirect()->back()->with('fail','Something went wrong');

		}else{
			return redirect()->to('index')->with('success','You are now registred successfully');
		}

		return view('Reparation/index',$data);
	}
	public function edit($id_repar){
	
		$reparat= new ReparModel();
		$user = new UserModel();
		$mater= new MaterModel();
		$inter= new InterModel();
        $data =[
            'user' => $user->findAll(),
			'materiel' => $mater->findAll(),
            'reparation' =>$reparat->find($id_repar),
			'inter' =>$inter->findAll(),
			'Inter'=>$inter->select_nom(),
            ] ;
        return view('Reparation/edit',$data);
	}
	public function update(){
		$reparat= new ReparModel();
        $id_repar =$this->request->getVar('id_repar');
		$data =[
			'date_recep'=> $this->request->getPost('dat'),
			'date_recup'=> $this->request->getPost('da'),
			'etat'=> $this->request->getPost('eta'),
			'observation'=> $this->request->getPost('obs'),
			'id_mate'=> $this->request->getPost('id'),
			'domaine'=> $this->request->getPost('dom'),
			'num_mat'=> $this->request->getPost('num'),
			'situation'=> $this->request->getPost('si'),
			'libelle'=> $this->request->getPost('lib'),
			'num_matri'=> $this->request->getPost('nume'),
		];
        $reparat->update($id_repar,$data);
		return $this->response->redirect(site_url('Reparation/index')); 
	}
	public function delete($id_repar){
		$reparat= new ReparModel();
		$reparat->delete($id_repar);

		return $this->response->redirect(site_url('Reparation/index'));
	}
	public function print(){
		$reparat= new ReparModel();
        $data  =[
			"reparation"=>$reparat->select_data()
		   ];
		return view('Excel/list',$data);
		
	}
	public function exportExcel(){
		$reparat= new ReparModel();
		$data  =$reparat->select_data();

		   $file_name='excel.xlsx';
		   $spreadsheet =new Spreadsheet();
		   $sheet=$spreadsheet->getActiveSheet();
		   $sheet->setCellValue('A1','Localisation');
		   $sheet->setCellValue('B1','Direction');
		   $sheet->setCellValue('C1','Departement');
		   $sheet->setCellValue('D1','Service');
		   $sheet->setCellValue('E1','Site');
		   $sheet->setCellValue('F1','Nom et Prénom');
		   $sheet->setCellValue('G1','Matricule');
		   $sheet->setCellValue('H1','Fonction');
		   $sheet->setCellValue('I1','Section analytique');
		   $sheet->setCellValue('J1','Code matériel');
		   $sheet->setCellValue('K1','Marque');
		   $sheet->setCellValue('L1','Model');
		   $sheet->setCellValue('M1','Num serie');
		   $sheet->setCellValue('N1','Caractéristique');
		   $sheet->setCellValue('O1','Etat');
		   $sheet->setCellValue('P1','Observation');
		   $count =2;
		   foreach($data as $row){
			   $sheet->setCellValue('A'.$count,$row['nom_local']);
			   $sheet->setCellValue('B'.$count,$row['code_dir']);
			   $sheet->setCellValue('C'.$count,$row['code_depar']);
			   $sheet->setCellValue('D'.$count,$row['code_serv']);
			   $sheet->setCellValue('E'.$count,$row['site']);
			   $sheet->setCellValue('F'.$count,$row['nom'].''.$row['prenom']);
			   $sheet->setCellValue('G'.$count,$row['num_mat']);
			   $sheet->setCellValue('H'.$count,$row['nom_fonction']);
			   $sheet->setCellValue('I'.$count,$row['code_sec']);
			   $sheet->setCellValue('J'.$count,$row['code_mate']);
			   $sheet->setCellValue('K'.$count,$row['marque']);
			   $sheet->setCellValue('L'.$count,$row['model']);
			   $sheet->setCellValue('M'.$count,$row['num_serie']);
			   $sheet->setCellValue('N'.$count,$row['caracteristique']);
			   $sheet->setCellValue('O'.$count,$row['etat']);
			   $sheet->setCellValue('P'.$count,$row['observation']);
		   }
		   $count++;
		   $writer = new Xlsx($spreadsheet);
		   $writer->save("upload/".$file_name);

		   header("Content-Type: application/vnd.ms-excel");
		   redirect(base_url()."/upload/".$file_name);
		
	}
	public function printExcel(){
		$reparat= new ReparModel();
        $data  =[
			"reparation"=>$reparat->select_data()
		   ];
		return view('Excel/list1',$data);
	}
	public function exportPrintExcel(){
		$reparat= new ReparModel();
		$data =array('title'=>'excel','reparation'=>$reparat->select_data());
		return view("Excel/export1",$data);
	}
   
}