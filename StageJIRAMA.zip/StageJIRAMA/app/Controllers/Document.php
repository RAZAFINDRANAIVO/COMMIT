<?php

namespace App\Controllers;
use App\Models\ReparModel;


class Document extends BaseController{
    public function index(String $id_repar){
        $reparat= new ReparModel();
        $data =[
            'reparation'=>$reparat->select_where($id_repar),
        ];

        $from='';
        $to='';
        $subject='';

        $email = \Config\Services::email();

        $email->setFrom($from);
        $email->setTo($to);
       

        $email->setSubject($subject);
        $email->setMessage('Testing the email class.');

        $email->send();

        return view('Email/document',$data);

    }
    
}