<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA6Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Liste</title>
        <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css')?>">
    </head>
    <body">
    <?php echo form_open() ?>
        <div class="container">
        <div class="row">
        <h5>Invantaire informatique</h5>
        </div>
        <div class="col">
        <a href="<?= site_url('Reparation/exportExcel'); ?>"><button>EXCEL</button></a>
        </div>
            <div class="row">
            <table border="1" width="100%">
                <thead>
                    <tr>
                        <th>Localisation</th>
                        <th>Direction</th>
                        <th>Departement</th>
                        <th>Service</th>
                        <th>Site</th>
                        <th>Nom et Prénom</th>
                        <th>Matricule</th>
                        <th>Fonction</th>
                        <th>Section analytique</th>
                        <th>Code matériel</th>
                        <th>Marque</th>
                        <th>Model</th>
                        <th>Num serie</th>
                        <th>Caractéristique</th>
                        <th>Etat</th>
                        <th>Observation</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($reparation as $key => $reparation): ?>
                    <tr>
                        <td><?= $reparation->nom_local ?></td>
                        <td><?= $reparation->code_dir ?></td>
                        <td><?= $reparation->code_depar ?></td>
                        <td><?= $reparation->code_serv ?></td>
                        <td><?= $reparation->site ?></td>
                        <td><?= $reparation->nom.' '.$reparation->prenom ?></td>
                        <td><?= $reparation->num_mat ?></td>
                        <td><?= $reparation->nom_fonction ?></td>
                        <td><?= $reparation->code_sect ?></td>
                        <td><?= $reparation->code_mate ?></td>
                        <td><?= $reparation->marque ?></td>
                        <td><?= $reparation->model ?></td>
                        <td><?= $reparation->num_serie ?></td>
                        <td><?= $reparation->caracteristique ?></td>
                        <td><?= $reparation->etat ?></td>
                        <td><?= $reparation->observation ?></td>
                    </tr>
                <?php endforeach ?>                    
               </tbody>
                                   
            </table>
            </div>

        </div>
    <?php echo form_close() ?>
    </body>
</html>