<?php
header("content-type:application/vnd-ms-excel");
header("content-Disposition:attachement;filename=Data reparation.xls");
?>
     <?php echo form_open() ?>
            <div class="row">
            <table border="1" width="100%">
                <thead>
                    <tr>
                        <th>Date réception</th>
                        <th>Libéllée de travaux</th>
                        <th>Demandeur</th>
                        <th>Domaine </th>
                        <th>Intervenant</th>
                        <th>Situation</th>
                        <th>Date réalisation</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($reparation as $key => $reparation): ?>
                    <tr>
                        <td><?= $reparation->date_recep ?></td>
                        <td><?= $reparation->libelle ?></td>
                        <td><?= $reparation->code_depar ?></td>
                        <td><?= $reparation->domaine ?></td>
                        <td><?= $reparation->num_inter ?></td>
                        <td><?= $reparation->situation ?></td>
                        <td><?= $reparation->date_recup ?></td>
                    </tr>
                <?php endforeach ?>                    
               </tbody>
                                   
            </table>
            </div>
    <?php echo form_close() ?>