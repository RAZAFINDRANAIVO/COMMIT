<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA6Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Liste</title>
        <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css')?>">
    </head>
    <body>
    <?php echo form_open() ?>
        <div class="container">
        <div class="row">
        <h5>Liste des travaux</h5>
        </div>
        <div class="col">
        <a href="exportPrintExcel"><button>Excel</button></a>
        </div>
            <div class="row">
            <table border="1" width="100%">
                <thead>
                    <tr>
                        <th>Date réception</th>
                        <th>Libéllée de travaux</th>
                        <th>Demandeur</th>
                        <th>Domaine </th>
                        <th>Intervenant</th>
                        <th>Situation</th>
                        <th>Date réalisation</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($reparation as $key => $reparation): ?>
                    <tr>
                        <td><?= $reparation->date_recep ?></td>
                        <td><?= $reparation->libelle ?></td>
                        <td><?= $reparation->code_depar ?></td>
                        <td><?= $reparation->domaine ?></td>
                        <td><?= $reparation->num_inter ?></td>
                        <td><?= $reparation->situation ?></td>
                        <td><?= $reparation->date_recup ?></td>
                    </tr>
                <?php endforeach ?>                    
               </tbody>
                                   
            </table>
            </div>

        </div>
    <?php echo form_close() ?>
    </body>
</html>