<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Departement</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
       <div class="container" >
            <div>
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           DEPARTEMENT
                        </h1>
                    </div>
            </div> 
            <div class="row"><a href="<?= base_url('Home') ?>">ACCUEIL</a> </div>
     <div  class="container" style="margin-top: 45px;">
        <div class="Container">
            <div>
                <table border="1" class="table table-bordered"" >
                    <thead>
                        <tr>
                            <th>Code Departement</th>
                            <th>Code Direction</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($departement as $key => $departement): ?>
                            <tr>
                                <td><?= $departement->code_depar ?></td>
                                <td><?= $departement->code_dir ?></td>
                                    
                               
                                <td>
                                   <a href="<?= site_url('Departement/edit/'.$departement->id_depar)?>" > EDITER </a> |
                                   <a href="<?= site_url('Departement/delete/'.$departement->id_depar)?>" >SUPPRIMER</a> 
                                </td>
                               
                            </tr>
                        <?php endforeach ?>
                     </tbody>
                </table>
            </div>
                 
         </div>
        <div class="container">
        <a href=" <?= site_url('Departement/add/')?>">Ajouter un nouveau departement</a>
        </div>
     </div>
                 
                  
                </div>
            </div>
        </div> 
</body>
</html>
  
