<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Departement</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
       <div class="container" >
            <div>
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           DEPARTEMENT
                        </h1>
                    </div>
                </div> 
                
               
            <form  action="<?=site_url('Departement/save/') ?>"  method="POST">
            <?= csrf_field(); ?>
            <div class="container">
               <table>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Code departement</label></td>
                        <td> <input type="text" name="code" class="form-control " value="<?= set_value('code') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Direction</label></td>
                        <td><select name="Code_dir" class="form-control " >
                        <option value="">Select direction</option>
                        <?php foreach ($direction as $key => $direction):?>
                        <option name="Code_dir" value="<?= $direction['id_dir']?>" ><?= $direction['code_dir']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>

                    <tr>
                      <td valign="top">&nbsp;</td>
                      <td><input type="submit" class="form-control btn-primary submit" value="Enregistrer"></td>
                    </tr>
               </table>
            </div>  
         </form>
    
         </div>
     </div>
</body>
</html>
  
