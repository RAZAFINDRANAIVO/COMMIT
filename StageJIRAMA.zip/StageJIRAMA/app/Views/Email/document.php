<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA6Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Document</title>
    </head>
    <body >
      <form action="<?= base_url('Document/index'); ?>">
      
      <div class="container">
           
           <div class="row">
               <div class="form-group col-lg-6 col-md-6">
                   <label>Matériel:</label>
                   <p><?= $reparation[0]->code_mate?></p>
               </div>
               <div class="form-group col-lg-6 col-md-6">
                   <label >Numéro de serie:</label>
                   <p> <?= $reparation[0]->num_serie ?></p>
               </div>
               <div class="form-group col-lg-6 col-md-6">
                   <label >Caracteristique de matériel:</label>
                   <p> <?= $reparation[0]->caracteristique ?></p>
               </div>
               <div class="form-group col-lg-6 col-md-6">
                   <label >Domaine:</label>
                   <p> <?= $reparation[0]->domaine ?></p>
               </div>
               <div class="form-group col-lg-6 col-md-6">
                   <label for="">Observation:</label>
                   <p> <?= $reparation[0]->observation ?></p>
               </div>
               <div class="form-group col-lg-6 col-md-6">
                   <label >Situation:</label>
                   <p> <?= $reparation[0]->situation ?></p>
               </div>
           </div>
        
         </div>
      </form>
   
    </body>
</html>