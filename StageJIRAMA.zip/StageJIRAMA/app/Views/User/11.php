<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
       <div class="container" >
            <div>
			 <div class="row">
                    <div class="col-md-12">
                        <h3 class="page-header">
                          Nouveau utilisateur
                        </h3>
                    </div>
                </div> 
                
               
            <form  action="<?=site_url('User/save/') ?>"  method="POST">
            <?= csrf_field(); ?>
            <div class="container">
                  <div >
                  <table>
                  <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Numéro matricule</label></td>
                        <td> <input type="text" name="num" class="form-control " value="<?= set_value('num') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Nom</label></td>
                        <td> <input type="text" name="nom" class="form-control " value="<?= set_value('nom') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Prénom</label></td>
                        <td> <input type="text" name="pre" class="form-control " value="<?= set_value('pre') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Catégorie</label></td>
                        <td> <input type="text" name="cate" class="form-control " value="<?= set_value('cate') ?>"> <br></td>
                    </div>
                    </tr>
                  </div>
                   <div class="row">
                   <table>
                   <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Phone</label></td>
                        <td> <input type="text" name="phone" class="form-control " value="<?= set_value('phone') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Email</label></td>
                        <td> <input type="text" name="email" class="form-control " value="<?= set_value('email') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Adresse</label></td>
                        <td> <input type="text" name="adr" class="form-control " value="<?= set_value('adr') ?>"> <br></td>
                    </div>
                    </tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Fonction</label></td>
                        <td><select name="code" class="form-control " >
                        <option value="">Select fonction</option>
                        <?php foreach ($fonction as $key => $fonction):?>
                        <option  value="<?= $fonction['id_fonc']?>" ><?= $fonction['nom_fonction']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Section</label></td>
                        <td><select name="id_se" class="form-control " >
                        <option value="">Select section</option>
                        <?php foreach ($section as $key => $section):?>
                        <option  value="<?= $section['id_sect']?>" ><?= $section['code_sect']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>

                    <tr>
                      <td valign="top">&nbsp;</td>
                      <td><input type="submit" class="form-control btn-primary submit" value="Enregistrer"></td>
                    </tr>
                    </table>
                   </div>
            </div>  
         </form>
    
         </div>
     </div>
</body>
</html>
  
