<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Departement</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
       <div class="container" >
            <div>
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                             Modifier l'utilisateur
                        </h1>
                    </div>
                </div> 
                
               
            <form  action="<?=site_url('User/update/') ?>"  method="POST">
            <?= csrf_field(); ?>
            <div class="container">
               <table>
                    <input type="hidden" name="num_mat" value="<?= $user['num_mat'] ?>"> 
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Numéro matricule</label></td>
                        <td> <input type="text" name="num" class="form-control " value="<?= $user['num_mat'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Nom</label></td>
                        <td> <input type="text" name="nom" class="form-control " value="<?= $user['nom'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Prénom</label></td>
                        <td> <input type="text" name="pre" class="form-control " value="<?= $user['prenom'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Catégorie</label></td>
                        <td> <input type="text" name="cate" class="form-control " value="<?= $user['categorie'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Phone</label></td>
                        <td> <input type="text" name="phone" class="form-control " value="<?= $user['tel'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Email</label></td>
                        <td> <input type="text" name="email" class="form-control " value="<?= $user['email'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Adresse</label></td>
                        <td> <input type="text" name="adr" class="form-control " value="<?= $user['adresse'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Fonctin</label></td>
                        <td><select name="id_se" class="form-control " >
                        <option value="">Select fonction</option>
                        <?php foreach ($fonction as $key => $fonction):?>
                        <option  <?= ($user['id_fonc'] == $fonction['id_fonc'] )? "selected":"" ?> value="<?= $fonction['id_fonc']?>" ><?= $fonction['nom_fonction']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Section</label></td>
                        <td><select name="code" class="form-control " >
                        <option value="">Select Section</option>
                        <?php foreach ($section as $key => $section):?>
                        <option  <?= ($user['id_sect'] == $section['id_sect'] )? "selected":"" ?> value="<?= $section['id_sect']?>" ><?= $section['code_sect']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>

                    <tr>
                      <td valign="top">&nbsp;</td>
                      <td><input type="submit" class="form-control btn-primary submit" value="Modifier"></td>
                    </tr>
               </table>
            </div> 
            
         </form>
    
         </div>
     </div>
</body>
</html>
  
