<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" href="images/DB_16х16.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GesParkI</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">


    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">


    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->

    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,300,100,700,900' rel='stylesheet'
          type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url('assets/css/lib/getmdl-select.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/lib/nv.d3.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/application.min.css') ?>">
    <!-- endinject -->
</head>
<body>
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header is-small-screen">
    <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
            <div class="mdl-layout-spacer"></div>
            <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                <label class="mdl-button mdl-js-button mdl-button--icon" for="search">
                    <i class="material-icons">search</i>
                </label>

                <div class="mdl-textfield__expandable-holder">
                    <input class="mdl-textfield__input" type="text" id="search"/>
                    <label class="mdl-textfield__label" for="search">Enter your query...</label>
                </div>
            </div>
        </div>
    </header> 
<div class="mdl-layout__drawer">
        <header>GesParkI</header>
        <div class="scroll__wrapper" id="scroll__wrapper">
            <div class="scroller" id="scroller">
                <div class="scroll__container" id="scroll__container">
                <nav class="mdl-navigation">
                            <a class="mdl-navigation__link" href="<?= base_url('Home') ?>">
                                <i class="material-icons" role="presentation">GesParkI</i>
                            </a>
                            <div class="sub-navigation">
                                <a class="mdl-navigation__link">
                                   <h5> Gestion interne</h5>
                                </a>
                                <div class="mdl-navigation">
                                    <a class="mdl-navigation__link" href="<?= site_url('Direction') ?>">
                                        Direction
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Departement') ?>">
                                        Departement
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Service') ?>">
                                        Service
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Section') ?>">
                                        Section analytique
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('LOcalisation') ?>">
                                        Localisation
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Fonction') ?>">
                                        Fonction
                                    </a>
                                </div>
                            </div>
                            <a class="mdl-navigation__link" href="<?= site_url('Materiel') ?>">
                                <h5>Gestion de matériel</h5>
                            </a>
                            <a class="mdl-navigation__link mdl-navigation__link--current" href="<?= site_url('User') ?>">
                                <h5>Gestion d'utilisateur</h5>
                               
                            </a>
                            <a class="mdl-navigation__link" href="<?= site_url('Reparation') ?>">
                                <h5>Gestion de réparation</h5>
                              
                            </a>
                            <div class="sub-navigation">
                                <a class="mdl-navigation__link">
                                   <h5>Compte</h5>
                                </a>
                                <div class="mdl-navigation">
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/index/') ?>">
                                       Se connecter
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/register/') ?>">
                                       Créer un nouveau compte
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/logout/') ?>">
                                        Se déconnecter
                                    </a>
                                </div>
                            </div>
                        </nav>
                </div>
            </div>
            <div class='scroller__bar' id="scroller__bar"></div>
        </div>
    </div>
    </div>
<div class="row">
    <main class="mdl-layout__content ">
    <div class="mdl-layout-spacer"></div>

        <div class="mdl-grid ui-tables">
            <div class="mdl-cell mdl-cell--12-col-desktop mdl-cell--12-col-tablet mdl-cell--4-col-phone">
                <div class="mdl-card mdl-shadow--2dp" style="margin-top: 45px;">
                    <div class="mdl-card__title">
                        <h1 class="mdl-card__title-text">Section analytique</h1>
                    </div>
                    <div class="mdl-card__supporting-text no-padding">
                        <table class="mdl-data-table mdl-js-data-table"  border="1">
                            <thead>
                            <tr>
                                <th class="mdl-data-table__cell--non-numeric">Code section analytique</th>
                                <th class="mdl-data-table__cell--non-numeric">Type</th>
                                <th class="mdl-data-table__cell--non-numeric">Code service</th>
                                <th class="mdl-data-table__cell--non-numeric">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($section as $key => $section): ?>
                                <tr>
                                    <td class="mdl-data-table__cell--non-numeric"><?= $section->code_sect?></td>
                                    <td class="mdl-data-table__cell--non-numeric"><?=  $section->type  ?></td>
                                    <td class="mdl-data-table__cell--non-numeric"><?=  $section->code_serv ?></td>
                                    <td class="mdl-data-table__cell--non-numeric">
                                        <a href="<?= site_url('Section/edit/'.$section->id_sect)?>" >  <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect button--colored-teal">Editer</button> </a> 
                                        <a href="<?= site_url('Section/delete/'.$section->id_sect)?>" > <button class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect button--colored-teal">Supprimer</button></a> 
                                    </td>
                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>
    </div>
</div>

<!-- inject:js -->
<script src="<?= base_url('assets/js/d3.min.js') ?>"></script>
<script src="<?= base_url('assets/js/getmdl-select.min.js') ?>"></script>
<script src="<?= base_url('assets/js/material.min.js') ?>"></script>
<script src="<?= base_url('assets/js/nv.d3.min.js') ?>"></script>
<script src="<?= base_url('assets/js/layout/layout.min.js') ?>"></script>
<script src="<?= base_url('assets/js/scroll/scroll.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/charts/discreteBarChart.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/charts/linePlusBarChart.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/charts/stackedBarChart.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/employer-form/employer-form.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/line-chart/line-charts-nvd3.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/map/maps.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/pie-chart/pie-charts-nvd3.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/table/table.min.js') ?>"></script>
<script src="<?= base_url('assets/js/widgets/todo/todo.min.js') ?>"></script>
<!-- endinject -->

</body>
</html>