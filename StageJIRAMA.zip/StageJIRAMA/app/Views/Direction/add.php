<!doctype html>
<!--
  Material Design Lite
  Copyright 2015 Google Inc. All rights reserved.

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License
-->
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <link rel="icon" type="image/png" href="images/DB_16х16.png">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GesPark</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">


    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">


    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->

    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,300,100,700,900' rel='stylesheet'
          type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url('assets/css/lib/getmdl-select.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/lib/nv.d3.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/application.min.css') ?>">
    <!-- endinject -->

</head>
<body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-drawer mdl-layout--fixed-header">
        <header class="mdl-layout__header">
            <div class="mdl-layout__header-row">
                <div class="mdl-layout-spacer"></div>
                <!-- Search-->
                <div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable">
                    <label class="mdl-button mdl-js-button mdl-button--icon" for="search">
                        <i class="material-icons">search</i>
                    </label>

                    <div class="mdl-textfield__expandable-holder">
                        <input class="mdl-textfield__input" type="text" id="search"/>
                        <label class="mdl-textfield__label" for="search">Enter your query...</label>
                    </div>
                </div>

                <div class="material-icons mdl-badge mdl-badge--overlap mdl-button--icon notification" id="notification"
                     data-badge="23">
                    notifications_none
                </div>     
            </div>
        </header>

        <div class="mdl-layout__drawer">
            <header>GesParki</header>
            <div class="scroll__wrapper" id="scroll__wrapper">
                <div class="scroller" id="scroller">
                    <div class="scroll__container" id="scroll__container">
                    <nav class="mdl-navigation">
                            <a class="mdl-navigation__link" href="<?= base_url('Home') ?>">
                                <i class="material-icons" role="presentation">GesParkI</i>
                            </a>
                            <div class="sub-navigation">
                                <a class="mdl-navigation__link">
                                   <h5> Gestion interne</h5>
                                </a>
                                <div class="mdl-navigation">
                                    <a class="mdl-navigation__link" href="<?= site_url('Direction') ?>">
                                        Direction
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Departement') ?>">
                                        Departement
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Service') ?>">
                                        Service
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Section') ?>">
                                        Section analytique
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('LOcalisation') ?>">
                                        Localisation
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Fonction') ?>">
                                        Fonction
                                    </a>
                                </div>
                            </div>
                            <a class="mdl-navigation__link" href="<?= site_url('Materiel') ?>">
                                <h5>Gestion de matériel</h5>
                            </a>
                            <a class="mdl-navigation__link " href="<?= site_url('User') ?>">
                                <h5>Gestion d'utilisateur</h5>
                               
                            </a>
                            <a class="mdl-navigation__link" href="<?= site_url('Reparation') ?>">
                                <h5>Gestion de réparation</h5>
                              
                            </a>
                            <div class="sub-navigation">
                                <a class="mdl-navigation__link">
                                   <h5>Compte</h5>
                                </a>
                                <div class="mdl-navigation">
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/index/') ?>">
                                       Se connecter
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/register/') ?>">
                                       Créer un nouveau compte
                                    </a>
                                    <a class="mdl-navigation__link" href="<?= site_url('Auth/logout/') ?>">
                                        Se déconnecter
                                    </a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class='scroller__bar' id="scroller__bar"></div>
            </div>
        </div>

        <main class="mdl-layout__content mdl-color--grey-100">
            <div class="mdl-card mdl-shadow--2dp employer-form" action="#">
                <div class="mdl-card__title">
                    <h2>Ajouter une Direction</h2>
                    <div class="mdl-card__subtitle"></div>
                </div>

                <div class="mdl-card__supporting-text">
                    <form action="<?=site_url('Direction/save/') ?>" class="form" method="post" >
                    <?= csrf_field(); ?>
                        <div class="form__article">
                            
                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <label for="firstName">Code de la directioon</label>
                                    <input class="mdl-textfield__input" name="code" type="text" id="firstName" value="<?= set_value('code') ?>"/>
                                    <span class="text-danger"> <?= isset($validation) ? display_error($validation,'code') :'' ?>
                                </div>

                                <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                    <label for="firstName">Site</label>
                                    <input class="mdl-textfield__input" name="site" type="text" id="firstName" value="<?= set_value('site') ?>"/>
                                    <span class="text-danger"><?=isset($validation)? display_error($validation,'site') : ''?>
                                </div>
                            
                            
                                 <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select">
                                    <div class="mdl-layout-spacer"></div>
                                 </div>
                            
                                 <div class="mdl-cell mdl-cell--6-col mdl-textfield mdl-js-textfield mdl-textfield--floating-label getmdl-select">
                                    <div class="mdl-layout-spacer"></div>
                                    <button class="mdl-button mdl-js-button mdl-button--raised color--light-blue" type="submit" >Enrégistrer</button>  
                                </div>
                           
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>

<!-- inject:js -->
<script src="js/d3.min.js"></script>
<script src="js/getmdl-select.min.js"></script>
<script src="js/material.min.js"></script>
<script src="js/nv.d3.min.js"></script>
<script src="js/layout/layout.min.js"></script>
<script src="js/scroll/scroll.min.js"></script>
<script src="js/widgets/charts/discreteBarChart.min.js"></script>
<script src="js/widgets/charts/linePlusBarChart.min.js"></script>
<script src="js/widgets/charts/stackedBarChart.min.js"></script>
<script src="js/widgets/employer-form/employer-form.min.js"></script>
<script src="js/widgets/line-chart/line-charts-nvd3.min.js"></script>
<script src="js/widgets/map/maps.min.js"></script>
<script src="js/widgets/pie-chart/pie-charts-nvd3.min.js"></script>
<script src="js/widgets/table/table.min.js"></script>
<script src="js/widgets/todo/todo.min.js"></script>
<!-- endinject -->

</body>
</html>

