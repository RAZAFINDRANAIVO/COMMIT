<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Direction</title>
        <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">

    </head>
    <body>
        <div class="container">
            <div class="row" style="margin-top: 45px;">
                <div>
                   <h2>Modiffier la direction</h2>
                </div>
               <div style="margin-top: 95px;">
               <form action="<?= site_url('Direction/update')?>" method="post">
                <table>
                    <input type="hidden" name="id_dir" value="<?= $direction['id_dir'] ?>">
                    <tr>
                        <td>Code de la direction</td>
                        <td><input type="text" name="code" class="form-control" value="<?= $direction['code_dir'] ?>"></td>
                        <td><span class="text-danger"><?=isset($validation)? display_error($validation,'serie') : ''?></span></td>
                    </tr>
                    <tr>
                        <td>Site</td>
                        <td><input type="text" name="site" class="form-control" value="<?= $direction['site'] ?>"></td>
                        <td><span class="text-danger"><?=isset($validation)? display_error($validation,'site') : ''?></span></td>
                    </tr>
                  
                    <tr>
                        <td valign="top">&nbsp;</td>
                        <td><button class="btn btn-primary btn-block" type="submit">MODIFIER</button></td>
                    </tr>
                </table>
               
                </form>
                </div>
                
            </div>
        </div>
    </body>
</html>