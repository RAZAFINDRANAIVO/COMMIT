<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Direction</title>
      <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">

</head>
<body>
      <div class="container">
            <div class="row" style="margin-top:45px;">
                  <div class="col-md-4 col-md-offset-4"">
                  <h2 class="text-center">Nouveau Direction</h2><hr>
                  <form action="<?= base_url('Direction/save'); ?>" method="post" >
                  <?= csrf_field(); ?>
                  <table>
                    <tr>
                        <td>Code de la Direction</td>
                        <td><input type="text" class="form-control" name="code"  value="<?= set_value('code')?>"></td>
                        <td><span class="text-danger"> <?= isset($validation) ? display_error($validation,'code') :'' ?></span></td>
                   
                    </tr>
                    <tr>
                      
                      <td>Site</td>
                      <td><input type="text" class="form-control" name="site" value="<?= set_value('site'); ?>"></td>
                      <td> <span class="text-danger"><?=isset($validation)? display_error($validation,'site') : ''?></span></td>
                   
                    </tr>
                   
                    <tr>
                        <td valign="top">&nbsp;</td>
                        <td><button class="btn btn-primary btn-block" type="submit">ENREGISTRER</button></td>
                    </tr>
                  </table>
                  
                   
                  </form>
                  </div>
            </div>
      </div>  
</body>
</html>