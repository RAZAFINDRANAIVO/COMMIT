<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reparation</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
       <div class="container" >
            <div>
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           Reparation
                        </h1>
                    </div>
                </div> 
                
               
            <form  action="<?=site_url('Reparation/update/') ?>"  method="POST">
            <?= csrf_field(); ?>
            <div class="container">
               <table>
                    <input type="hidden" name="id_depar" value="<?= $reparation['id_repar'] ?>">
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Date recepetion</label></td>
                        <td> <input type="date" name="dat" class="form-control " value="<?= $reparation['date_recep'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Date réalisation</label></td>
                        <td> <input type="date" name="da" class="form-control " value="<?= $reparation['date_recup'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Etat</label></td>
                        <td> <input type="text" name="eta" class="form-control " value="<?= $reparation['etat'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Observetion</label></td>
                        <td> <input type="text" name="obs" class="form-control " value="<?= $reparation['observation'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Materiel</label></td>
                        <td><select name="id" class="form-control " >
                        <option value="">Select Materiel</option>
                        <?php foreach ($materiel as $key => $materiel):?>
                        <option  <?= ($materiel['id_mate'] == $reparation['id_mate'] )? "selected":"" ?> value="<?= $materiel['id_mate']?>" ><?= $materiel['code_mate'].' / '.$materiel['num_serie']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>
                    <tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Domaine</label></td>
                        <td> <input type="text" name="dom" class="form-control " value="<?= $reparation['domaine'] ?>"> <br></td>
                    </div>
                    </tr>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Utilisateur</label></td>
                        <td><select name="num" class="form-control " >
                        <option value="">Select direction</option>
                        <?php foreach ($user as $key => $user):?>
                        <option  <?= ($reparation['num_mat'] == $user['num_mat'] )? "selected":"" ?> value="<?= $user['num_mat']?>" ><?= $user['nom'].' '.$user['prenom']?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>
                    <div class="form-group col-md-4">
                        <td><label for="">Situation</label></td>
                        <td> <input type="text" name="si" class="form-control " value="<?= $reparation['situation'] ?>"> <br></td>
                    </div>
                    <div class="form-group col-md-4">
                        <td><label for="">Libellée</label></td>
                        <td> <input type="text" name="lib" class="form-control " value="<?= $reparation['libelle'] ?>"> <br></td>
                    </div>
                    <tr><div class="form-group col-md-4">
                        <td><label for="">Intervenant</label></td>
                        <td><select name="nume" class="form-control " >
                        <option value="">Select intervenant</option>
                        <?php foreach ($nom as $key => $nom):?>
                        <option  <?= ($reparation['num_inter'] )? "selected":"" ?> value="<?= $nom->nom.' '.$nom->prenom?>" ><?=  $nom->nom.' '.$nom->prenom?></option>
                        <?php endforeach ?>
                        </select> <br> </td>
                    </div></tr>

                    <tr>
                      <td valign="top">&nbsp;</td>
                      <td><input type="submit" class="form-control btn-primary submit" value="Modifier"></td>
                    </tr>
               </table>
            </div> 
            
         </form>
    
         </div>
     </div>
</body>
</html>
  
